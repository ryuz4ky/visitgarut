"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.YoutubeImportError = exports.youtubeImportMessages = void 0;
exports.youtubeApiErrorCode = youtubeApiErrorCode;
exports.normalizeYoutubeComments = normalizeYoutubeComments;
exports.youtubeImportMessages = {
    youtube: 'Impor belum berhasil. Coba kembali atau periksa sumber video.',
    youtube_comments_disabled: 'Komentar dinonaktifkan oleh pemilik video. Pilih video lain yang komentarnya terbuka.',
    youtube_video_unavailable: 'Video tidak ditemukan atau tidak dapat diakses melalui API. Periksa tautan video.',
    youtube_access: 'Akses YouTube API ditolak. Periksa aktivasi API dan pembatasan API key di Google Cloud.',
    youtube_daily_budget: 'Batas pengumpulan harian VisitGarut tercapai. Antrean akan dilanjutkan pada hari kuota berikutnya.',
    youtube_quota: 'Kuota YouTube API habis atau batas permintaan tercapai. Coba kembali setelah kuota tersedia.',
    youtube_connection: 'Koneksi ke YouTube belum berhasil. Coba kembali beberapa saat.',
    youtube_consent: 'Baca dan centang persetujuan sebelum mengimpor komentar.',
    youtube_content: 'Pilih video YouTube yang sudah disetujui di Konten sosial.',
    youtube_invalid_id: 'ID video YouTube tidak valid. Periksa tautan pada Konten sosial.',
    youtube_empty: 'Tidak ada komentar yang memenuhi batas 20–4.000 karakter pada 50 komentar terbaru video ini.',
    youtube_storage: 'Komentar belum berhasil disimpan. Tidak ada perubahan dari percobaan impor ini; coba kembali.'
};
class YoutubeImportError extends Error {
    code;
    constructor(code) {
        super(exports.youtubeImportMessages[code]);
        this.code = code;
        this.name = 'YoutubeImportError';
    }
}
exports.YoutubeImportError = YoutubeImportError;
function youtubeApiErrorCode(reason, status) {
    if (reason === 'commentsDisabled')
        return 'youtube_comments_disabled';
    if (reason === 'videoNotFound' || status === 404)
        return 'youtube_video_unavailable';
    if (['quotaExceeded', 'dailyLimitExceeded', 'rateLimitExceeded', 'userRateLimitExceeded'].includes(reason) || status === 429)
        return 'youtube_quota';
    return status === 400 || status === 401 || status === 403 ? 'youtube_access' : 'youtube_connection';
}
function normalizeYoutubeComments(items, videoId) {
    return items.map(t => { const c = t.snippet.topLevelComment; return { id: c.id, author: c.snippet.authorDisplayName, authorId: c.snippet.authorChannelId?.value || '', text: c.snippet.textOriginal || c.snippet.textDisplay, publishedAt: c.snippet.publishedAt, likes: c.snippet.likeCount, sourceUrl: `https://www.youtube.com/watch?v=${videoId}&lc=${encodeURIComponent(c.id)}` }; }).filter(c => {
        // PostgreSQL length(text) counts Unicode characters; JS string.length counts UTF-16 units.
        const length = Array.from(c.text).length;
        return length >= 20 && length <= 4000;
    });
}
