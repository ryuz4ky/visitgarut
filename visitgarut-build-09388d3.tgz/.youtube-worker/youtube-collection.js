"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.YoutubeCollectionApi = void 0;
exports.locationQueries = locationQueries;
const youtube_core_1 = require("./youtube-core");
function locationQueries(name, aliases = []) {
    const canonical = name.split(/\s+[–—]\s+/)[0].trim();
    const short = canonical.replace(/^(Gunung|Pantai|Curug|Situ|Desa Wisata|Taman Air)\s+/i, '');
    const terms = [...new Set([canonical, short, ...aliases].map(s => s.trim().replace(/["|]/g, '')).filter(s => s.length >= 4 && !/^(rental|sewa)\s+(mobil|motor)\s+garut$/i.test(s)))].slice(0, 4);
    return terms.flatMap(term => { const q = '"' + term + '"' + (/\bgarut\b/i.test(term) ? '' : ' Garut'); return [{ q, order: 'relevance' }, { q, order: 'date' }]; });
}
function rawComment(c) {
    const s = c.snippet;
    return { id: c.id, parentId: s.parentId || null, author: s.authorDisplayName, authorId: s.authorChannelId?.value || '', text: s.textOriginal ?? s.textDisplay, publishedAt: s.publishedAt, likes: s.likeCount || 0 };
}
class YoutubeCollectionApi {
    key;
    reserve;
    request;
    constructor(key, reserve, request = fetch) {
        this.key = key;
        this.reserve = reserve;
        this.request = request;
    }
    async call(endpoint, params, bucket) {
        if (!this.key)
            throw new youtube_core_1.YoutubeImportError('youtube_access');
        await this.reserve(bucket);
        const u = new URL('https://www.googleapis.com/youtube/v3/' + endpoint);
        u.search = new URLSearchParams({ ...params, key: this.key }).toString();
        try {
            const r = await this.request(u, { signal: AbortSignal.timeout(12000), cache: 'no-store' });
            const data = await r.json();
            if (!r.ok)
                throw new youtube_core_1.YoutubeImportError((0, youtube_core_1.youtubeApiErrorCode)(data.error?.errors?.[0]?.reason || '', r.status));
            return data;
        }
        catch (e) {
            if (e instanceof youtube_core_1.YoutubeImportError)
                throw e;
            throw new youtube_core_1.YoutubeImportError('youtube_connection');
        }
    }
    async search(query, page = '') { const d = await this.call('search', { part: 'snippet', type: 'video', q: query.q, order: query.order, maxResults: '50', relevanceLanguage: 'id', regionCode: 'ID', ...(page ? { pageToken: page } : {}) }, 'search'); return { items: (d.items || []).filter((v) => /^[\w-]{11}$/.test(v.id.videoId || '')).map((v) => ({ id: v.id.videoId, title: v.snippet.title, description: v.snippet.description, channelId: v.snippet.channelId, channelTitle: v.snippet.channelTitle, publishedAt: v.snippet.publishedAt })), next: d.nextPageToken || '' }; }
    async threads(video, page = '') { const d = await this.call('commentThreads', { part: 'snippet', videoId: video, maxResults: '100', order: 'time', textFormat: 'plainText', ...(page ? { pageToken: page } : {}) }, 'data'); return { items: (d.items || []).map((t) => ({ comment: rawComment(t.snippet.topLevelComment), replyCount: t.snippet.totalReplyCount || 0 })), next: d.nextPageToken || '' }; }
    async replies(parent, page = '') { const d = await this.call('comments', { part: 'snippet', parentId: parent, maxResults: '100', textFormat: 'plainText', ...(page ? { pageToken: page } : {}) }, 'data'); return { items: (d.items || []).map(rawComment), next: d.nextPageToken || '' }; }
}
exports.YoutubeCollectionApi = YoutubeCollectionApi;
